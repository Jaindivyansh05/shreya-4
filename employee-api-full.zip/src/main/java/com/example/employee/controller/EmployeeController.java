package com.example.employee.controller;

import com.example.employee.dto.CreateEmployeeRequest;
import com.example.employee.entity.Employee;
import com.example.employee.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

  private final EmployeeService service;

  public EmployeeController(EmployeeService service) { this.service = service; }

  @PostMapping
  public ResponseEntity<Employee> create(@Valid @RequestBody CreateEmployeeRequest req) {
    Employee saved = service.create(Employee.builder()
        .name(req.name()).role(req.role()).email(req.email()).build());
    return ResponseEntity.created(URI.create("/api/employees/" + saved.getId())).body(saved);
  }

  @GetMapping
  public List<Employee> all() { return service.findAll(); }

  @GetMapping("/{id}")
  public Employee byId(@PathVariable Long id) { return service.findById(id); }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable Long id) {
    service.deleteById(id);
    return ResponseEntity.noContent().build();
  }
}
