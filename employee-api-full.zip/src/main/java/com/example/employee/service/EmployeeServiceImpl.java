package com.example.employee.service;

import com.example.employee.entity.Employee;
import com.example.employee.exception.NotFoundException;
import com.example.employee.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

  private final EmployeeRepository repo;

  public EmployeeServiceImpl(EmployeeRepository repo) { this.repo = repo; }

  @Override
  public Employee create(Employee e) { return repo.save(e); }

  @Override
  public List<Employee> findAll() { return repo.findAll(); }

  @Override
  public Employee findById(Long id) {
    return repo.findById(id).orElseThrow(() -> new NotFoundException("Employee %d not found".formatted(id)));
  }

  @Override
  public void deleteById(Long id) {
    if (!repo.existsById(id)) {
      throw new NotFoundException("Employee %d not found".formatted(id));
    }
    repo.deleteById(id);
  }
}
