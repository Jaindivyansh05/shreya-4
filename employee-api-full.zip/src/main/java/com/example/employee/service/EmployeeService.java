package com.example.employee.service;

import com.example.employee.entity.Employee;

import java.util.List;

public interface EmployeeService {
  Employee create(Employee e);
  List<Employee> findAll();
  Employee findById(Long id);
  void deleteById(Long id);
}
