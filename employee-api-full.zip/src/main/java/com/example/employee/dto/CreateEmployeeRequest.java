package com.example.employee.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record CreateEmployeeRequest(
    @NotBlank String name,
    @NotBlank String role,
    @Email String email
) {}
