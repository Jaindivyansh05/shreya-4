package com.example.employee.service;

import com.example.employee.entity.Employee;
import com.example.employee.exception.NotFoundException;
import com.example.employee.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceTest {

  @Mock private EmployeeRepository repo;
  private EmployeeService service;

  @BeforeEach
  void setup() { service = new EmployeeServiceImpl(repo); }

  @Test
  void create_saves_and_returns_employee() {
    Employee e = Employee.builder().name("Shreya").role("Analyst").email("s@ex.com").build();
    Employee saved = Employee.builder().id(1L).name("Shreya").role("Analyst").email("s@ex.com").build();
    when(repo.save(e)).thenReturn(saved);

    Employee result = service.create(e);
    assertEquals(1L, result.getId());
    verify(repo).save(e);
  }

  @Test
  void findAll_returns_list() {
    when(repo.findAll()).thenReturn(List.of(new Employee()));
    assertEquals(1, service.findAll().size());
    verify(repo).findAll();
  }

  @Test
  void findById_found() {
    Employee saved = Employee.builder().id(42L).name("A").role("B").email("a@b.com").build();
    when(repo.findById(42L)).thenReturn(Optional.of(saved));

    Employee result = service.findById(42L);
    assertEquals(42L, result.getId());
  }

  @Test
  void findById_notFound_throws() {
    when(repo.findById(99L)).thenReturn(Optional.empty());
    assertThrows(NotFoundException.class, () -> service.findById(99L));
  }

  @Test
  void deleteById_existing_deletes() {
    when(repo.existsById(5L)).thenReturn(true);
    service.deleteById(5L);
    verify(repo).deleteById(5L);
  }

  @Test
  void deleteById_missing_throws() {
    when(repo.existsById(5L)).thenReturn(false);
    assertThrows(NotFoundException.class, () -> service.deleteById(5L));
    verify(repo, never()).deleteById(anyLong());
  }
}
