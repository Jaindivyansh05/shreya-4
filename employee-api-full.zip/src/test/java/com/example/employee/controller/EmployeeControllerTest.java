package com.example.employee.controller;

import com.example.employee.dto.CreateEmployeeRequest;
import com.example.employee.entity.Employee;
import com.example.employee.exception.GlobalExceptionHandler;
import com.example.employee.exception.NotFoundException;
import com.example.employee.service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = EmployeeController.class)
@Import(GlobalExceptionHandler.class)
class EmployeeControllerTest {

  @Autowired private MockMvc mvc;
  @Autowired private ObjectMapper om;

  @MockBean private EmployeeService service;

  @Test
  void POST_create_returns201_and_body() throws Exception {
    CreateEmployeeRequest req = new CreateEmployeeRequest("Shreya","Analyst","s@ex.com");
    Employee saved = Employee.builder().id(1L).name("Shreya").role("Analyst").email("s@ex.com").build();
    when(service.create(any())).thenReturn(saved);

    mvc.perform(post("/api/employees")
            .contentType(MediaType.APPLICATION_JSON)
            .content(om.writeValueAsString(req)))
        .andExpect(status().isCreated())
        .andExpect(header().string("Location", "/api/employees/1"))
        .andExpect(jsonPath("$.id").value(1));
  }

  @Test
  void POST_create_validation_failure_returns400() throws Exception {
    String payload = "{\"name\":\"Shreya\",\"role\":\"Analyst\",\"email\":\"\"}";
    mvc.perform(post("/api/employees")
            .contentType(MediaType.APPLICATION_JSON)
            .content(payload))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.error").value("VALIDATION_FAILED"));
  }

  @Test
  void GET_all_returns200_and_list() throws Exception {
    when(service.findAll()).thenReturn(List.of(
        Employee.builder().id(1L).name("A").role("X").email("a@b.com").build()
    ));

    mvc.perform(get("/api/employees"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$[0].id").value(1));
  }

  @Test
  void GET_byId_found_returns200() throws Exception {
    when(service.findById(2L)).thenReturn(
        Employee.builder().id(2L).name("B").role("Y").email("b@c.com").build()
    );

    mvc.perform(get("/api/employees/2"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.email").value("b@c.com"));
  }

  @Test
  void GET_byId_missing_returns404() throws Exception {
    when(service.findById(99L)).thenThrow(new NotFoundException("not found"));

    mvc.perform(get("/api/employees/99"))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("$.error").value("NOT_FOUND"));
  }

  @Test
  void DELETE_byId_returns204() throws Exception {
    mvc.perform(delete("/api/employees/5"))
        .andExpect(status().isNoContent());
    verify(service).deleteById(5L);
  }
}
