# Employee API (Spring Boot, TDD, JaCoCo, SonarQube, Jenkins)

## Quickstart (local)
```bash
# Java 17 + Maven required
mvn clean verify
mvn spring-boot:run

# Sample calls
curl -X POST http://localhost:8080/api/employees -H "Content-Type: application/json" -d '{"name":"Shreya","role":"Analyst","email":"shreya@example.com"}'
curl http://localhost:8080/api/employees
curl http://localhost:8080/api/employees/1
curl -X DELETE http://localhost:8080/api/employees/1
```
